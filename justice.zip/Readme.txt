------------
BORING INFO:
------------

JusticeAmp

Amp finished on 11. July 1998
This is my second skin after the Kill 'em All Amp. I have to admit,
my amps are getting better. Yes, there are also some minor adjustments
that need to be made. 

Name: David "Freak" Freerksen II
E-mail: eet_fuk@metallicafan.com  -or-  df_challenger18@hotmail.com
Instant Messenger Name: Rageforth
ICQ#: 10837701

Also, check out my web page at:
http://www.geocities.com/SunsetStrip/Cabaret/7963
It is called The Metallica Downloads Archive
(there are more Metallica skins on my page too)

I hope you enjoy the skin!