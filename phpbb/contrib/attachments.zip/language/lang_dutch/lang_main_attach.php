<?php
/***************************************************************************
 *                            lang_main_attach.php [Dutch]
 *                              -------------------
 *     begin                : Thu Feb 07 2002
 *     copyright            : (C) 2002 Matthijs van de Water
 *     email                : matthijs@beryllium.net
 *
 *     $Id: lang_main_attach.php,v 2.1.1 2002/03/25 meik Exp $
 *
 ****************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 ***************************************************************************/

//
// Attachment Mod Main Language Variables
//

// Viewforum
$lang['Rules_attach_can'] = "Je <b>mag</b> attachments plaatsen in dit forum";
$lang['Rules_attach_cannot'] = "Je <b>mag geen</b> attachments plaatsen in dit forum";

// Viewtopic
$lang['Mime_type_disallowed_post'] = "Mime Type %s is door een beheerder uitgeschakeld, daarom kan dit attachment niet worden weergegeven"; // used in Posts, replace %s with mime type

// Posting/Replying (Not private messaging!)
$lang['Disallowed_extension'] = "De extentie %s is niet toegestaan"; // replace %s with extension (e.g. .php) 
$lang['Disallowed_Mime_Type'] = "Niet toegestaan Mime Type: %s<p>Toegestane Typen zijn:<br />%s"; // mime type, allowed types 
$lang['Attachment_too_big'] = "Het Attachment is te groot.<br />Maximale Grootte: %d %s"; // replace %d with maximum file size, %s with size var
$lang['Attachment_php_size_overrun'] = "Het Attachment is te groot.<br />Maximaal toegestane grootte in PHP: %d MB"; // replace %d with ini_get('upload_max_filesize')
$lang['Invalid_filename'] = "%s is een ongeldige bestandsnaam"; // replace %s with given filename
$lang['General_upload_error'] = "Upload fout: Kan het attachment niet uploaden naar %s"; // replace %s with local path 
   
$lang['Add_attachment'] = "Voeg Attachment Toe";
$lang['Add_attachment_title'] = "Voeg een Attachment toe";
$lang['Add_attachment_explain'] = "Als je geen attachment wil toevoegen aan je bericht, laat deze velden dan leeg";
$lang['File_name'] = "Bestandsnaam";
$lang['File_comment'] = "Bestand Beschrijving";
$lang['Delete_attachments'] = "Verwijder Attachments";
$lang['Delete_attachment'] = "Verwijder Attachment";
$lang['Posted_attachments'] = "Geplaatste Attachments";
$lang['Update_comment'] = "Beschrijving Bijwerken";

// Auth related entries
$lang['Sorry_auth_attach'] = "Sorry, maar alleen %s mogen attachments plaatsen in dit forum";

// Download Count functionality
$lang['Download_number'] = "Bestand %d keer gedownload of bekeken"; // replace %d with count

// Errors at posting
$lang['Sorry_auth_view_attach'] = "Sorry, maar je mag dit attachment niet downloaden";
$lang['No_file_comment_available'] = "Geen Bestands Beschrijving beschikbaar";
$lang['Too_many_attachments'] = "Het attachment kan niet toegevoegd worden, omdat het maximale aantal van %d attachments in dit bericht bereikt is"; // replace %d with maximum number of attachments
$lang['Attach_quota_reached'] = "Sorry, maar de maximaal toegestane bestandsgrootte voor alle attachments is bereikt. Neem contact op met de beheerder als je hierover vragen hebt.";

// Errors at download
$lang['Error_no_attachment'] = "Het geselecteerde attachment bestaat niet meer";
$lang['No_attachment_selected'] = "Je hebt geen attachment geselecteerd om te downloaden of bekijken";
$lang['Attachment_feature_disabled'] = "De Attachment Optie is uitgeschakeld";

// Errors on Upload Directory
// replace %s with directory
$lang['Directory_does_not_exist'] = "De Directory '%s' bestaat niet of kan niet gevonden worden";
$lang['Directory_is_not_a_dir'] = "Het lijkt erop dat '%s' geen directory is.";
$lang['Directory_not_writeable'] = "De Directory '%s' is niet beschrijfbaar. Je moet de upload directory aanmaken en deze 777 chmod-den (of de eigenaar naar je de eigenaar van je webserver veranderen) om bestanden te kunnen uploaden.<br />Als je alleen FTP toegang hebt, verander dan de 'Attribute' van de directory naar rwxrwxrwx.";

// Size related Variables
$lang['Bytes'] = "Bytes";
$lang['KB'] = "KB";
$lang['MB'] = "MB";

$lang['Attach_search_query'] = "Zoek Attachments";

?>