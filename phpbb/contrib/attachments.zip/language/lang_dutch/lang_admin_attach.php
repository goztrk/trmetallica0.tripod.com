<?php
/***************************************************************************
 *                            lang_admin_attach.php [English]
 *                              -------------------
 *     begin                : Thu Feb 07 2002
 *     copyright            : (C) 2002 Matthijs van de Water
 *     email                : matthijs@beryllium.net
 *
 *     $Id: lang_admin_attach.php,v 2.1.1 2002/03/25 meik Exp $
 *
 ****************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 ***************************************************************************/

//
// Attachment Mod Admin Language Variables
//

// Modules, this replaces the keys used
$lang['Attachments'] = "Attachments";
$lang['Attachment'] = "Attachment";

$lang['Extension_control'] = "Extensie Management";

$lang['Extensions'] = "Extensie";
$lang['Extension'] = "Extensie";
$lang['Mimetypes'] = "Mime Types"; 
$lang['Mimetype'] = "Mime Type"; 
$lang['Mimegroups'] = "Mime Groepen";
$lang['Mimegroup'] = "Mime Groep";

// Auth pages
$lang['Attach'] = "Attachments";

// Attachments
$lang['Select_action'] = "Selecteer een Actie";

// Attachments -> Management
$lang['Manage_attachments_explain'] = "Hier kan je de globale instellingen voor de Attachment Mod veranderen";
$lang['Attach_settings'] = "Attachment Instellingen";
$lang['Upload_directory'] = "Upload Directory";
$lang['Attach_img_path'] = "Pad naar een plaatje voor attachments";
$lang['Attach_topic_icon'] = "Attachment Topic Plaatje";
$lang['Attach_topic_icon_explain'] = "Dit plaatje wordt getoond voor een topic waarin attachments geplaatst zijn. Laat dit veld leeg als je geen plaatje wil tonen.";
$lang['Display_images'] = "Toon Plaatjes";
$lang['Display_images_explain'] = "Toon upgeloade plaatjes in plaats van het plaatsen van een link";
$lang['Max_filesize_attach'] = "Bestandsformaat";
$lang['Max_filesize_attach_explain'] = "Maximum bestandsformaat voor attachments (in Bytes). Een waarde van 0 betekend 'oneindig'.";
$lang['Attach_quota'] = "Attachment Quotum";
$lang['Attach_quota_explain'] = "Hier kan je een maximum definieren voor ALLE attachments";
$lang['Max_attachments'] = "Maximum aantal attachments";
$lang['Max_attachments_explain'] = "Hier kan je het maximum aantal toegestane attachments per bericht opgeven.";
$lang['Disable_mod'] = "Schakel de Attachment Mod uit";
$lang['Disable_mod_explain'] = "Deze optie is vooral voor het testen van nieuwe templates en thema's, hiermee schakel je alle attachment functies uit, behalve die in het Administratiepaneel";
$lang['Attach_config_updated'] = "Attachment Instelleningen Succesvol Aangepast";
$lang['Click_return_attach_config'] = "Klik %shier%s om terug te keren naar de Attachment Instellingen";

// Attachments -> Extension Control
$lang['Manage_forbidden_extensions'] = "Beheer Verboden Extensies";
$lang['Manage_forbidden_extensions_explain'] = "Hier kan je verboden extensies toevoegen of verwijderen. De extensies php, php3 en php4 zijn automatisch verboden, je kunt deze niet verwijderen.";
$lang['Extension_exist'] = "Extensie %s bestaat al"; // replace %s with the extension

// Attachments -> Mime Types
$lang['Manage_mime_types'] = "Beheer Mime Typen";
$lang['Manage_mime_types_explain'] = "Hier kan je de Mime Typen beheren. Als je een Mime Type wil toestaan of verbieden, gebruik dan het Mime Groepen Beheer.";
$lang['Explanation'] = "Beschrijving";
$lang['Invalid_mimetype'] = "Ongeldig Mime Type";
$lang['Mimetype_exist'] = "Mime Type %s bestaat al"; // replace %s with the mimetype

// Attachments -> Mime Groups
$lang['Manage_mime_groups'] = "Mime Groepen Beheer";
$lang['Manage_mime_groups_explain'] = "Hier kan je Mime Groepen toevoegen, verwijderen of aanpassen, je kan Mime Groepen verbieden en een Plaatjes group definieren.";
$lang['Image_group'] = "Plaatjes Groep";
$lang['Allowed'] = "Toegestaan";
$lang['Mimegroup_exist'] = "Mime Groep %s bestaat al"; // replace %s with the mimetype
$lang['Special_category'] = "Speciale Categorie";
$lang['Category_images'] = "plaatjes";
$lang['Category_wma_files'] = "wma bestanden";
$lang['Category_swf_files'] = "flash bestanden";

$lang['Download_mode'] = "Download Modus";
$lang['Upload_image'] = "Upload Plaatje";
$lang['Max_filesize'] = "Maximum Bestandsgrootte";

$lang['Collapse'] = "Uitklappen";
$lang['Decollapse'] = "Inklappen";

// Attachments -> Shadow Attachments
$lang['Shadow_attachments'] = "Schaduw Attachments";		// used in modules-list
$lang['Shadow_attachments_title'] = "Schaduw Attachments";
$lang['Shadow_attachments_explain'] = "Hier kan je de attachments verwijderen die aan een bericht zijn gekoppeld, maar niet meer op het bestandssysteem aanwezig zijn, en de bestanden verwijderen die op het bestandssysteem aanwezig zijn, maar niet zijn gekoppeld aan een bericht. Je kan een bestand downloaden of bekijken door op de link klikken, als er geen link is, is het bestand niet aanwezig.";
$lang['Shadow_attachments_file_explain'] = "Verwijder alle Attachments die op het bestandssysteem staan, maar niet aan een bericht zijn gekoppeld.";
$lang['Shadow_attachments_row_explain'] = "Verwijder alle Attachment informatie voor attachments niet op het bestandssysteem staan.";

// Attachments -> Control Panel
$lang['Control_Panel'] = "Controle Paneel";
$lang['Control_panel_title'] = "Attachment Bestanden Controle Panel";
$lang['Control_panel_explain'] = "Hier kan je alle attachments bekijken en beheren op basis van gebruikers, attachments, downloads, etc.";

$lang['File_comment_cp'] = "Bestand Beschrijving";

// Sort Types
$lang['Sort_Attachments'] = "Attachments";
$lang['Sort_Size'] = "Grootte";
$lang['Sort_Filename'] = "Bestandsnaam";
$lang['Sort_Comment'] = "Beschrijving";
$lang['Sort_Mimegroup'] = "Mimegroep";
$lang['Sort_Mimetype'] = "Mimetype";
$lang['Sort_Downloads'] = "Downloads";
$lang['Sort_Posttime'] = "Tijd";
$lang['Sort_Posts'] = "Berichten";

// View Types
$lang['View_Statistic'] = "Statistiek";
$lang['View_Search'] = "Zoek";
$lang['View_Username'] = "Gebruikersnaam";
$lang['View_Attachments'] = "Attachments";

// Control Panel -> Statistics
$lang['Number_of_attachments'] = "Aantal Attachments";
$lang['Total_filesize'] = "Totale Bestandsgrootte";
$lang['Number_posts_attach'] = "Aantal Berichten met Attachments";
$lang['Number_topics_attach'] = "Aantal Topics met Attachments";
$lang['Number_users_attach'] = "Aantal Gebruikers dat Attachments heeft geplaatst";

// Control Panel -> Search
$lang['Search_wildcard_explain'] = "Gebruik een * als wildcard voor gedeeltelijke resultaten";
$lang['Size_smaller_than'] = "Attachment grootte kleiner dan (bytes)";
$lang['Size_greater_than'] = "Attachment grootte meer dan (bytes)";
$lang['Count_smaller_than'] = "Aantal downloads is kleiner dan";
$lang['Count_greater_than'] = "Aantal downloads is groter dan";
$lang['More_days_old'] = "Meer dan zoveel dagen oud";
$lang['No_attach_search_match'] = "Je zoekopdracht leverde geen Attachments op";

// Control Panel -> Attachments
$lang['Statistics_for_user'] = "Attachment Statistieken voor %s"; // replace %s with username
$lang['Size_in_kb'] = "Grootte (KB)";
$lang['Downloads'] = "Downloads";
$lang['Post_time'] = "Tijd";
$lang['Posted_in_topic'] = "Geplaatst in Topic";
$lang['Confirm_delete_attachments'] = "Weet je zeker dat je de geselecteerde attachments wil verwijderen";
$lang['Deleted_attachments'] = "De geselecteerde attachments zijn verwijderd";
$lang['Error_deleted_attachments'] = "Kan de attachments niet verwijderen";

?>