------------
BORING INFO:
------------

This is my second skin after Deathamp, and im quite happy about it.
Well, it needs some adjustments, but hell, what doesn't?

Yeah, this is version 6.666 if you didn't catch it.

Mail me at:
George "Raven" "LiQuid-IC" Jacobsson
smurflandet@rocketmail.com

E-mailbomb this person (just kiddin'):
Daniel "Pempan" Gustavsson
len-guv@algonet.se